param(
    [string]$RepoRoot = (Get-Location).Path,
    [string]$CodeMap = "",
    [switch]$SkipVerify,
    [switch]$SkipRefresh
)

$ErrorActionPreference = "Stop"

$ScriptDir = Split-Path -Parent $PSCommandPath
$PlanPath = Join-Path $ScriptDir "plan.yml"

if (-not (Test-Path $PlanPath)) {
    throw "Missing plan.yml next to apply.ps1: $PlanPath"
}

$RepoRoot = (Resolve-Path $RepoRoot).Path
if (-not (Test-Path (Join-Path $RepoRoot "Cargo.toml"))) {
    throw "RepoRoot does not look like the Amigo repository root: $RepoRoot"
}

function Invoke-CodeMap {
    param([Parameter(Mandatory = $true)][string[]]$Args)

    Push-Location $RepoRoot
    try {
        if ($CodeMap -and $CodeMap.Trim().Length -gt 0) {
            & $CodeMap @Args
        }
        else {
            $LocalExe = Join-Path $RepoRoot "target\debug\amigo-codemap.exe"
            if (Test-Path $LocalExe) {
                & $LocalExe @Args
            }
            else {
                & cargo run -p amigo-codemap -- @Args
            }
        }

        if ($LASTEXITCODE -ne 0) {
            throw "amigo-codemap failed with exit code $LASTEXITCODE: $($Args -join ' ')"
        }
    }
    finally {
        Pop-Location
    }
}

function Invoke-RepoCommand {
    param(
        [Parameter(Mandatory = $true)][string]$Command,
        [string]$WorkingDirectory = $RepoRoot
    )

    Push-Location $WorkingDirectory
    try {
        Write-Host "[VERIFY] $Command"
        & powershell -NoProfile -ExecutionPolicy Bypass -Command $Command
        if ($LASTEXITCODE -ne 0) {
            throw "Verify command failed with exit code $LASTEXITCODE: $Command"
        }
    }
    finally {
        Pop-Location
    }
}

Write-Host "[AMIGO] Applying metadata catalog foundation pack"
Write-Host "[AMIGO] RepoRoot: $RepoRoot"
Write-Host "[AMIGO] Plan: $PlanPath"

Invoke-CodeMap @("ops-preview", "--from", $PlanPath, "--limit", "9999")
Invoke-CodeMap @("ops-check", "--from", $PlanPath, "--strict", "--limit", "9999")
Invoke-CodeMap @("ops-apply", "--from", $PlanPath, "--write", "--backup", "--stop-on-error", "--strict", "--limit", "9999")

if (-not $SkipRefresh) {
    Invoke-CodeMap @("refresh")
}

if (-not $SkipVerify) {
    Invoke-RepoCommand "cargo test -p amigo-editor editor_metadata --lib"
    Invoke-RepoCommand "cargo check -p amigo-editor"
    Invoke-RepoCommand "npm run build" (Join-Path $RepoRoot "crates\apps\amigo-editor")
    Invoke-RepoCommand "cargo test -p amigo-codemap"
}

Write-Host "[AMIGO] Metadata catalog foundation pack applied."
