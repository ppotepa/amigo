import { boundsOf, centroid, lerp, remapClamp, smoothstep } from "./math";
import { createEl } from "./dom";
import {
  type AppNodes,
  type EarKey,
  type EarState,
  type GeometryKind,
  type GeometryPayload,
  NS,
  type NodeRef,
  type OutlinePolicy,
  type Point,
  type SurfaceNode,
  type UiRefs,
  type ViewState,
} from "./types";

function createPartGroup(id: string): SVGGElement {
  return createEl("g", { "data-part": id });
}

function createSurfaceNode(key: string): SurfaceNode {
  const group = createPartGroup(key);
  const base = group.appendChild(createEl("path", { class: "surfaceBase" }));
  const shade = group.appendChild(createEl("path", { class: "surfaceShade", fill: "url(#shadowGradient)" }));
  const light = group.appendChild(createEl("path", { class: "surfaceLight", fill: "url(#lightGradient)" }));
  const wire = group.appendChild(createEl("path", { class: "wirePath" }));
  return { group, base, shade, light, wire };
}

export function createAppNodes(ui: UiRefs): AppNodes {
  const face = createSurfaceNode("face");
  const earRight = createSurfaceNode("earRight");
  const earLeft = createSurfaceNode("earLeft");

  const noseGroup = createPartGroup("nose");
  const nose = {
    group: noseGroup,
    path: noseGroup.appendChild(createEl("path", { class: "svgNose" })),
    highlight: noseGroup.appendChild(createEl("path", { class: "noseHighlight" })),
    nostril: noseGroup.appendChild(createEl("ellipse", { class: "nostril" })),
    wire: noseGroup.appendChild(createEl("path", { class: "wirePath" })),
  };

  const mouthGroup = createPartGroup("mouth");
  const mouth = {
    group: mouthGroup,
    path: mouthGroup.appendChild(createEl("path", { class: "mouthLine" })),
  };

  const outlineGroup = ui.outlineLayer.appendChild(createEl("g", { "data-part": "outlines" }));
  const outlines = {
    face: outlineGroup.appendChild(createEl("path", { class: "partOutline" })),
    nose: outlineGroup.appendChild(createEl("path", { class: "partOutline strong" })),
    earRight: outlineGroup.appendChild(createEl("path", { class: "partOutline" })),
    earLeft: outlineGroup.appendChild(createEl("path", { class: "partOutline" })),
    earRightInner: outlineGroup.appendChild(createEl("path", { class: "detailContour" })),
    earLeftInner: outlineGroup.appendChild(createEl("path", { class: "detailContour" })),
  };

  const masterGroup = ui.outlineLayer.appendChild(createEl("g", { class: "masterSilhouetteUnion" }));
  const masterSilhouette = {
    group: masterGroup,
    face: masterGroup.appendChild(createEl("path")),
    nose: masterGroup.appendChild(createEl("path")),
    earRight: masterGroup.appendChild(createEl("path")),
    earLeft: masterGroup.appendChild(createEl("path")),
  };

  ui.rigLayer.appendChild(face.group);
  ui.rigLayer.appendChild(earRight.group);
  ui.rigLayer.appendChild(earLeft.group);
  ui.rigLayer.appendChild(nose.group);
  ui.rigLayer.appendChild(mouth.group);

  return { face, earRight, earLeft, nose, mouth, outlines, masterSilhouette };
}

export function ensureDots(ui: UiRefs, dots: SVGCircleElement[], count: number): SVGCircleElement[] {
  while (dots.length < count) {
    const dot = createEl("circle", { class: "dot", r: "3.4" });
    ui.debugLayer.appendChild(dot);
    dots.push(dot);
  }
  return dots;
}

export function setGradientDirection(ui: UiRefs, points: Point[], side: 1 | -1, t: number): void {
  const bounds = boundsOf(points);
  const shadowNearX = side > 0 ? bounds.minX + bounds.width * 0.34 : bounds.maxX - bounds.width * 0.34;
  const lightNearX = side > 0 ? bounds.maxX - bounds.width * 0.18 : bounds.minX + bounds.width * 0.18;
  const blend = 0.22 + t * 0.22;
  const midY = bounds.minY + bounds.height * 0.52;
  const shadowY2 = bounds.maxY - bounds.height * 0.12;
  const lightY2 = bounds.maxY - bounds.height * 0.18;

  ui.shadowStop1.parentElement?.setAttribute("x1", shadowNearX.toFixed(2));
  ui.shadowStop1.parentElement?.setAttribute("y1", midY.toFixed(2));
  ui.shadowStop1.parentElement?.setAttribute("x2", (shadowNearX + side * bounds.width * blend).toFixed(2));
  ui.shadowStop1.parentElement?.setAttribute("y2", shadowY2.toFixed(2));

  ui.lightStop1.parentElement?.setAttribute("x1", lightNearX.toFixed(2));
  ui.lightStop1.parentElement?.setAttribute("y1", (bounds.minY + bounds.height * 0.18).toFixed(2));
  ui.lightStop1.parentElement?.setAttribute("x2", (lightNearX - side * bounds.width * 0.25).toFixed(2));
  ui.lightStop1.parentElement?.setAttribute("y2", lightY2.toFixed(2));
}

export function renderSources(ui: UiRefs, side: 1 | -1, backT = 0): void {
  ui.sourceGuides.innerHTML = "";
  const centerSelectors = ["#CENTER #FACE", "#CENTER #NOSE", side > 0 ? "#CENTER #PRAWE" : "#CENTER #LEWE"];
  const profileSelectors = [
    "#LEFT_PROFILE #FACE_PROFILE",
    "#LEFT_PROFILE #NOSE-PROFILE",
    "#LEFT_PROFILE #EAR_LEFT",
  ];

  for (const selector of centerSelectors) {
    const path = document.querySelector<SVGPathElement>(selector);
    if (!path) continue;
    ui.sourceGuides.appendChild(createEl("path", { class: "ghostPath centerGhost", d: path.getAttribute("d") ?? "" }));
  }

  for (const selector of profileSelectors) {
    const path = document.querySelector<SVGPathElement>(selector);
    if (!path) continue;
    const ghost = createEl("path", { class: "ghostPath profileGhost", d: path.getAttribute("d") ?? "" });
    if (side < 0) {
      ghost.setAttribute("transform", "translate(1080,0) scale(-1,1)");
    }
    ui.sourceGuides.appendChild(ghost);
  }

  ui.sourceGuides.style.opacity = String(1 - smoothstep(remapClamp(backT, 0.45, 1.0)) * 0.58);
}

export function computeLayerOrder(viewState: ViewState): Array<EarKey | "face" | "nose" | "mouth"> {
  if (viewState.zone === "FRONT" || viewState.zone === "BACK_PROXY") {
    return ["earLeft", "earRight", "face", "nose", "mouth"];
  }
  return [viewState.farEar.key, "face", viewState.nearEar.key, "nose", "mouth"];
}

export function applyLayerOrder(ui: UiRefs, nodes: AppNodes, order: Array<EarKey | "face" | "nose" | "mouth">): void {
  const lookup = {
    earRight: nodes.earRight.group,
    earLeft: nodes.earLeft.group,
    face: nodes.face.group,
    nose: nodes.nose.group,
    mouth: nodes.mouth.group,
  };
  for (const key of order) ui.rigLayer.appendChild(lookup[key]);
  for (const key of Object.keys(lookup) as (keyof typeof lookup)[]) lookup[key].style.opacity = "1";
  ui.hudOrder.textContent = `order: ${order.join(" → ")}`;
}

export function applyMassGeometry(nodes: AppNodes, nodeRef: NodeRef, geometry: GeometryPayload): void {
  if (!geometry.path) return;
  if (nodeRef === "face") {
    nodes.face.base.setAttribute("d", geometry.path);
    nodes.face.shade.setAttribute("d", geometry.path);
    nodes.face.light.setAttribute("d", geometry.path);
    nodes.face.wire.setAttribute("d", geometry.path);
    nodes.face.group.style.display = geometry.visible === false ? "none" : "inline";
    nodes.face.base.style.opacity = String(geometry.opacity ?? 1);
    nodes.face.shade.style.opacity = String(geometry.meta?.shadeOpacity ?? 1);
    nodes.face.light.style.opacity = String(geometry.meta?.lightOpacity ?? 1);
    return;
  }
  if (nodeRef === "nose") {
    nodes.nose.path.setAttribute("d", geometry.path);
    nodes.nose.wire.setAttribute("d", geometry.path);
    nodes.nose.group.style.display = geometry.visible === false ? "none" : "inline";
    nodes.nose.path.style.opacity = String(geometry.opacity ?? 1);
    nodes.nose.path.style.fill = "var(--skin)";
    nodes.nose.path.style.stroke = "transparent";
    return;
  }
  if (nodeRef === "earRight" || nodeRef === "earLeft") {
    const node = nodeRef === "earRight" ? nodes.earRight : nodes.earLeft;
    node.base.setAttribute("d", geometry.path);
    node.shade.setAttribute("d", geometry.path);
    node.light.setAttribute("d", geometry.path);
    node.wire.setAttribute("d", geometry.path);
    node.group.style.display = geometry.visible === false ? "none" : "inline";
    node.base.style.opacity = String(geometry.opacity ?? 1);
    node.base.style.fill = "var(--skin)";
    node.base.style.stroke = "transparent";
    node.shade.style.opacity = String(geometry.meta?.shadeOpacity ?? 1);
    node.light.style.opacity = String(geometry.meta?.lightOpacity ?? 1);
  }
}

export function applyDetailGeometry(
  nodes: AppNodes,
  kind: GeometryKind,
  geometry: GeometryPayload | null,
  side?: "left" | "right",
): void {
  if (kind === "mouthLine") {
    nodes.mouth.group.style.display = geometry?.visible === false || !geometry?.path ? "none" : "inline";
    if (geometry?.path) {
      nodes.mouth.path.setAttribute("d", geometry.path);
      nodes.mouth.path.style.opacity = String(geometry.opacity ?? 1);
    }
    return;
  }
  if (kind === "noseHighlight") {
    nodes.nose.highlight.style.display = geometry?.visible === false || !geometry?.path ? "none" : "inline";
    if (geometry?.path) {
      nodes.nose.highlight.setAttribute("d", geometry.path);
      nodes.nose.highlight.style.opacity = String(geometry.opacity ?? 1);
    }
    return;
  }
  if (kind === "nostril") {
    nodes.nose.nostril.style.display = geometry?.visible === false || !geometry?.meta ? "none" : "inline";
    if (geometry?.meta) {
      nodes.nose.nostril.setAttribute("cx", String(geometry.meta.cx ?? ""));
      nodes.nose.nostril.setAttribute("cy", String(geometry.meta.cy ?? ""));
      nodes.nose.nostril.setAttribute("rx", String(geometry.meta.rx ?? ""));
      nodes.nose.nostril.setAttribute("ry", String(geometry.meta.ry ?? ""));
      nodes.nose.nostril.style.opacity = String(geometry.opacity ?? 1);
    }
    return;
  }
  if (kind === "earInnerCurve") {
    const path = side === "right" ? nodes.outlines.earRightInner : nodes.outlines.earLeftInner;
    path.style.display = geometry?.visible === false || !geometry?.path ? "none" : "inline";
    if (geometry?.path) {
      path.setAttribute("d", geometry.path);
      path.style.opacity = String(geometry.opacity ?? 1);
    }
  }
}

export function applyVisibilityPolicy(nodes: AppNodes, viewState: ViewState, policy: OutlinePolicy): void {
  nodes.nose.group.style.display = viewState.showNose ? "inline" : "none";
  nodes.mouth.group.style.display = policy.drawMouth ? "inline" : "none";
  nodes.nose.path.style.display = policy.drawNoseBody ? "inline" : "none";
  nodes.earRight.group.style.display = "inline";
  nodes.earLeft.group.style.display = "inline";
}

export function renderMouth(nodes: AppNodes, facePoints: Point[], viewState: ViewState): void {
  const bounds = boundsOf(facePoints);
  const center = centroid(facePoints);
  const nearSign = viewState.side > 0 ? -1 : 1;
  const t = viewState.t;
  const mouthY = center.y + bounds.height * 0.23;
  const mouthW = lerp(bounds.width * 0.14, bounds.width * 0.09, t);
  const mouthTilt = viewState.side * t * bounds.height * 0.015;
  const mouthX = center.x + nearSign * t * bounds.width * 0.015;
  nodes.mouth.path.setAttribute(
    "d",
    `M ${(mouthX - mouthW).toFixed(2)} ${(mouthY - mouthTilt).toFixed(2)} Q ${mouthX.toFixed(2)} ${(mouthY + bounds.height * 0.018).toFixed(2)}, ${(mouthX + mouthW).toFixed(2)} ${(mouthY + mouthTilt).toFixed(2)}`,
  );
  nodes.mouth.path.style.opacity = "1";
}

export function renderNoseDetail(nodes: AppNodes, nosePoints: Point[], viewState: ViewState, policy: OutlinePolicy): void {
  if (!policy.drawNoseDetail) {
    nodes.nose.highlight.style.display = "none";
    nodes.nose.nostril.style.display = "none";
    return;
  }
  nodes.nose.highlight.style.display = "inline";
  nodes.nose.nostril.style.display = "inline";
  const bounds = boundsOf(nosePoints);
  const center = centroid(nosePoints);
  const sign = viewState.side > 0 ? -1 : 1;
  const t = viewState.t;
  nodes.nose.highlight.setAttribute(
    "d",
    `M ${(center.x - sign * bounds.width * 0.10).toFixed(2)} ${(bounds.minY + bounds.height * 0.20).toFixed(2)} Q ${(center.x - sign * bounds.width * 0.18).toFixed(2)} ${center.y.toFixed(2)}, ${(center.x - sign * bounds.width * 0.10).toFixed(2)} ${(bounds.minY + bounds.height * 0.84).toFixed(2)}`,
  );
  nodes.nose.highlight.style.opacity = (0.08 + t * 0.18).toFixed(3);
  nodes.nose.nostril.setAttribute("cx", (center.x + sign * bounds.width * 0.17).toFixed(2));
  nodes.nose.nostril.setAttribute("cy", (bounds.minY + bounds.height * 0.72).toFixed(2));
  nodes.nose.nostril.setAttribute("rx", Math.max(1.0, bounds.width * lerp(0.032, 0.055, t)).toFixed(2));
  nodes.nose.nostril.setAttribute("ry", Math.max(0.6, bounds.height * lerp(0.015, 0.025, t)).toFixed(2));
  nodes.nose.nostril.style.opacity = (0.04 + t * 0.18).toFixed(3);
}

export function renderEarInnerLine(nodes: AppNodes, partKey: EarKey, earPoints: Point[], earState: EarState, policy: OutlinePolicy): void {
  const path = nodes.outlines[`${partKey}Inner`];
  const earPolicy = policy.ears[partKey];
  if (!earPolicy.drawInner) {
    path.style.display = "none";
    return;
  }
  path.style.display = "inline";
  const bounds = boundsOf(earPoints);
  const cx = bounds.minX + bounds.width * 0.52;
  const y1 = bounds.minY + bounds.height * 0.22;
  const y2 = bounds.minY + bounds.height * 0.78;
  const curve = bounds.width * (earState.localSide > 0 ? -0.18 : 0.18) * (earState.depth >= 0 ? 1 : -1);
  path.setAttribute(
    "d",
    `M ${cx.toFixed(2)} ${y1.toFixed(2)} C ${(cx + curve).toFixed(2)} ${(y1 + bounds.height * 0.18).toFixed(2)}, ${(cx - curve * 0.65).toFixed(2)} ${(y2 - bounds.height * 0.18).toFixed(2)}, ${cx.toFixed(2)} ${y2.toFixed(2)}`,
  );
  path.style.opacity = "1";
}

export function renderEarSurface(nodes: AppNodes, partKey: EarKey, d: string, earState: EarState): void {
  const node = nodes[partKey];
  node.base.setAttribute("d", d);
  node.shade.setAttribute("d", d);
  node.light.setAttribute("d", d);
  node.wire.setAttribute("d", d);
  node.base.style.fill = "var(--skin)";
  node.base.style.stroke = "transparent";
  node.base.style.opacity = "1";
  const nearBoost = earState.isNear ? 1 : 0;
  const farFade = earState.isFar ? 0.72 : 1;
  node.shade.style.opacity = String((0.22 + 0.22 * (1 - earState.fusion) + 0.10 * nearBoost) * farFade);
  node.light.style.opacity = String(0.28 + 0.12 * (1 - earState.fusion));
}

export function renderPartOutlines(nodes: AppNodes, paths: Record<string, string>, policy: OutlinePolicy): void {
  const pairs: Array<[keyof typeof nodes.outlines, boolean]> = [
    ["face", policy.drawFaceStroke],
    ["nose", policy.drawNoseStroke],
    ["earRight", policy.ears.earRight.drawStroke],
    ["earLeft", policy.ears.earLeft.drawStroke],
  ];

  for (const [key, draw] of pairs) {
    const path = nodes.outlines[key];
    if (!draw || !paths[key]) {
      path.style.display = "none";
      continue;
    }
    path.style.display = "inline";
    path.setAttribute("d", paths[key]);
    path.style.opacity = "1";
  }
}

export function renderMasterSilhouette(nodes: AppNodes, paths: Record<string, string>, viewState: ViewState, policy: OutlinePolicy, outlineMode: string): void {
  nodes.masterSilhouette.group.style.display = policy.drawMasterSilhouette ? "inline" : "none";
  if (!policy.drawMasterSilhouette) return;
  const includeNose = viewState.showNose && (outlineMode === "FULL" || viewState.noseFusion > 0.12 || policy.drawNoseBody);
  nodes.masterSilhouette.face.setAttribute("d", paths.face || "");
  nodes.masterSilhouette.nose.setAttribute("d", includeNose ? (paths.nose || "") : "");
  nodes.masterSilhouette.earRight.setAttribute("d", policy.ears.earRight.drawSilhouette ? (paths.earRight || "") : "");
  nodes.masterSilhouette.earLeft.setAttribute("d", policy.ears.earLeft.drawSilhouette ? (paths.earLeft || "") : "");
}

export function modeName(viewState: ViewState): string {
  const sideName = viewState.side > 0 ? "LEFT" : "RIGHT";
  if (viewState.zone === "FRONT") return `zone: FRONT / nose ${viewState.noseMode}`;
  if (viewState.zone === "BACK_PROXY") return "zone: BACK_PROXY / nose+mouth state-hidden";
  return `zone: ${viewState.zone} ${sideName} / nose ${viewState.noseMode}`;
}

export function injectInlineStyles(target: SVGSVGElement): void {
  const styleText = Array.from(document.styleSheets)
    .map(sheet => {
      try {
        return Array.from(sheet.cssRules).map(rule => rule.cssText).join("\n");
      } catch {
        return "";
      }
    })
    .filter(Boolean)
    .join("\n");

  if (!styleText) return;
  const style = document.createElementNS(NS, "style");
  style.textContent = styleText;
  target.insertBefore(style, target.firstChild);
}
