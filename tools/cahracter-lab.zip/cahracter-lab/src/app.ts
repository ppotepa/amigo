import { getUiRefs } from "./dom";
import { exportCurrentSvg } from "./export";
import { evaluateDetailGeometry, evaluateMassGeometry } from "./geometry";
import {
  applyDetailGeometry,
  applyLayerOrder,
  applyMassGeometry,
  applyVisibilityPolicy,
  createAppNodes,
  ensureDots,
  modeName,
  renderMasterSilhouette,
  renderPartOutlines,
  renderSources,
  setGradientDirection,
} from "./render";
import { computeRigViewState } from "./rig";
import { computeFusionGroups, computeRenderPasses, computeViewContext, createHeadSceneGraph, evaluateBodyPart, flattenParts } from "./scene-graph";
import { computeOutlinePolicy } from "./policies/outline";
import { type AppNodes, type AppState, type EvaluatedBodyPart, type GeometryPayload, type NodeRef } from "./types";

export class CharacterLabApp {
  private readonly ui = getUiRefs();
  private readonly nodes: AppNodes = createAppNodes(this.ui);
  private readonly bodyTree = createHeadSceneGraph();
  private readonly state: AppState = {
    yaw: 0,
    samples: Number(this.ui.samples.value),
    smooth: Number(this.ui.smooth.value),
    depth: Number(this.ui.depth.value),
    outlineMode: this.ui.outlineMode.value as AppState["outlineMode"],
    auto: false,
    rigs: new Map(),
    earRigs: new Map(),
    dots: [],
    lastTime: 0,
    dragging: false,
    dragStartX: 0,
    dragStartYaw: 0,
  };

  init(): void {
    this.bindEvents();
    this.rebuild();
    requestAnimationFrame(this.tick);
  }

  private readonly tick = (time: number): void => {
    if (!this.state.lastTime) this.state.lastTime = time;
    const dt = Math.min(64, time - this.state.lastTime);
    this.state.lastTime = time;
    if (this.state.auto) this.setYaw(this.state.yaw + dt * 0.035);
    requestAnimationFrame(this.tick);
  };

  private bindEvents(): void {
    this.ui.yaw.addEventListener("input", event => this.setYaw((event.target as HTMLInputElement).value));
    this.ui.outlineMode.addEventListener("input", () => {
      this.state.outlineMode = this.ui.outlineMode.value as AppState["outlineMode"];
      this.render();
    });
    this.ui.samples.addEventListener("input", () => this.rebuild());
    this.ui.smooth.addEventListener("input", () => this.rebuild());
    this.ui.depth.addEventListener("input", () => this.rebuild());
    this.ui.auto.addEventListener("input", () => {
      this.state.auto = this.ui.auto.checked;
    });
    this.ui.sources.addEventListener("input", () => this.render());
    this.ui.wire.addEventListener("input", () => this.render());
    this.ui.dots.addEventListener("input", () => this.render());
    this.ui.exportSvg.addEventListener("click", () => exportCurrentSvg(this.ui, () => this.render(), this.state.yaw));
    this.ui.buttons.forEach(button => button.addEventListener("click", () => this.setYaw(Number(button.dataset.yaw))));

    this.ui.stage.addEventListener("pointerdown", event => {
      this.state.dragging = true;
      this.state.dragStartX = event.clientX;
      this.state.dragStartYaw = this.state.yaw;
      this.ui.stage.setPointerCapture(event.pointerId);
    });
    this.ui.stage.addEventListener("pointermove", event => {
      if (!this.state.dragging) return;
      const dx = event.clientX - this.state.dragStartX;
      this.setYaw(this.state.dragStartYaw + dx * 0.5);
    });
    this.ui.stage.addEventListener("pointerup", event => {
      this.state.dragging = false;
      this.ui.stage.releasePointerCapture(event.pointerId);
    });
    this.ui.stage.addEventListener("pointercancel", () => {
      this.state.dragging = false;
    });
  }

  private setYaw(value: number | string): void {
    this.state.yaw = ((Number(value) % 360) + 360) % 360;
    this.render();
  }

  private rebuild(): void {
    this.state.samples = Number(this.ui.samples.value);
    this.state.smooth = Number(this.ui.smooth.value);
    this.state.depth = Number(this.ui.depth.value);
    this.state.rigs.clear();
    this.state.earRigs.clear();
    this.render();
  }

  private attachGeometry(flatParts: EvaluatedBodyPart[], viewState: ReturnType<typeof computeRigViewState>, yaw: number, yawRad: number): Map<string, GeometryPayload> {
    const geometryById = new Map<string, GeometryPayload>();

    for (const part of flatParts) {
      if (part.type !== "mass") continue;
      const geometry = evaluateMassGeometry(part.source, this.state, viewState, yaw, yawRad);
      part.geometry = geometry;
      if (geometry) geometryById.set(part.id, geometry);
    }

    const faceGeometry = geometryById.get("face") ?? null;
    const noseGeometry = geometryById.get("nose") ?? null;
    const rightEarGeometry = geometryById.get("earRight") ?? null;
    const leftEarGeometry = geometryById.get("earLeft") ?? null;

    for (const part of flatParts) {
      if (part.type !== "detail") continue;
      const parentGeometry =
        part.source.geometry?.dependsOn === "face" ? faceGeometry :
        part.source.geometry?.dependsOn === "nose" ? noseGeometry :
        part.source.geometry?.dependsOn === "earRight" ? rightEarGeometry :
        part.source.geometry?.dependsOn === "earLeft" ? leftEarGeometry :
        null;
      const geometry = evaluateDetailGeometry(part.source, parentGeometry, viewState, this.state.outlineMode);
      part.geometry = geometry;
      if (geometry) geometryById.set(part.id, geometry);
    }

    return geometryById;
  }

  private render(): void {
    const yaw = ((this.state.yaw % 360) + 360) % 360;
    const rad = yaw * Math.PI / 180;
    const viewContext = computeViewContext(yaw);
    const viewState = computeRigViewState(rad, yaw);
    const policy = computeOutlinePolicy(viewState, this.state.outlineMode);
    const evaluatedTree = evaluateBodyPart(this.bodyTree, viewContext);
    const flatParts = flattenParts(evaluatedTree);
    const geometryById = this.attachGeometry(flatParts, viewState, yaw, rad);
    const fusionGroups = computeFusionGroups(flatParts);
    const renderList = computeRenderPasses(flatParts);
    const paths: Record<string, string> = { face: "", nose: "", earRight: "", earLeft: "" };
    const facePoints = geometryById.get("face")?.points ?? null;
    const t = viewState.t;
    let dotPoints: GeometryPayload["points"] = [];

    for (const part of renderList) {
      if (!part.source.geometry || !part.geometry) continue;
      if (part.type === "mass" && part.source.nodeRef) {
        applyMassGeometry(this.nodes, part.source.nodeRef, part.geometry);
        if (part.geometry.path && (part.source.nodeRef === "face" || part.source.nodeRef === "nose" || part.source.nodeRef === "earRight" || part.source.nodeRef === "earLeft")) {
          paths[part.source.nodeRef] = part.geometry.path;
        }
        if (part.source.nodeRef === "face" && part.geometry.points) {
          const step = Math.max(1, Math.floor(part.geometry.points.length / 36));
          dotPoints = part.geometry.points.filter((_, index) => index % step === 0);
        }
        continue;
      }
      if (part.type === "detail") {
        applyDetailGeometry(this.nodes, part.source.geometry.kind, part.geometry, part.source.geometry.side);
      }
    }

    if (facePoints) {
      setGradientDirection(this.ui, facePoints, viewState.side, t);
    }
    renderPartOutlines(this.nodes, paths, policy);
    renderMasterSilhouette(this.nodes, paths, viewState, policy, this.state.outlineMode);
    applyVisibilityPolicy(this.nodes, viewState, policy);
    const layerOrder = renderList
      .map(part => part.source.nodeRef)
      .filter((nodeRef): nodeRef is NodeRef => Boolean(nodeRef))
      .filter((nodeRef, index, items) => items.indexOf(nodeRef) === index);
    applyLayerOrder(this.ui, this.nodes, layerOrder as Array<"earRight" | "earLeft" | "face" | "nose" | "mouth">);

    this.state.dots = ensureDots(this.ui, this.state.dots, dotPoints.length);
    dotPoints.forEach((point, index) => {
      if (!point) return;
      this.state.dots[index].setAttribute("cx", point.x.toFixed(2));
      this.state.dots[index].setAttribute("cy", point.y.toFixed(2));
    });

    const centerPct = Math.round((1 - t) * 100);
    const profilePct = Math.round(t * 100);
    this.ui.yaw.value = String(Math.round(yaw));
    this.ui.yawOut.textContent = `${Math.round(yaw)}°`;
    this.ui.outlineOut.textContent = this.state.outlineMode;
    this.ui.samplesOut.textContent = `${this.state.samples}`;
    this.ui.smoothOut.textContent = this.state.smooth.toFixed(2);
    this.ui.depthOut.textContent = this.state.depth.toFixed(2);
    this.ui.hudYaw.textContent = `yaw: ${Math.round(yaw)}°`;
    const backPct = Math.round(viewState.back * 100);
    this.ui.hudBlend.textContent = `blend: CENTER ${centerPct}% → PROFILE ${profilePct}% / BACK ${backPct}%`;
    this.ui.hudMode.textContent = modeName(viewState);
    const skinFusion = fusionGroups.get("skin")?.length ?? 0;
    this.ui.hudFusion.textContent = `fusion: nose ${viewState.noseFusion.toFixed(2)} / R ${viewState.earRight.fusion.toFixed(2)} / L ${viewState.earLeft.fusion.toFixed(2)} / skin ${skinFusion}`;
    this.ui.hudOutline.textContent = `outline: ${this.state.outlineMode}`;
    this.ui.stage.classList.toggle("showSources", this.ui.sources.checked);
    this.ui.stage.classList.toggle("showWire", this.ui.wire.checked);
    this.ui.stage.classList.toggle("showDots", this.ui.dots.checked);
    this.ui.buttons.forEach(button => {
      const value = Number(button.dataset.yaw);
      button.classList.toggle("active", Math.abs(value - Math.round(yaw)) < 1);
    });
    renderSources(this.ui, viewState.side, viewContext.back);
  }
}
