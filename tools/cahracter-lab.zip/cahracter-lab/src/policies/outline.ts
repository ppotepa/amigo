import { OUTLINE_MODES, type EarState, type OutlineMode, type OutlinePolicy, type ViewState } from "../types";

function computeEarPolicy(earState: EarState, viewState: ViewState, mode: OutlineMode) {
  const isProfileFar = earState.isFar && viewState.profile > 0.64;
  const isBackSide = viewState.back > 0.62;
  if (mode === OUTLINE_MODES.FULL) {
    return { drawBody: true, drawStroke: true, drawInner: true, drawSilhouette: true };
  }
  if (mode === OUTLINE_MODES.SILHOUETTE_ONLY) {
    return { drawBody: true, drawStroke: false, drawInner: false, drawSilhouette: !isProfileFar };
  }
  if (mode === OUTLINE_MODES.PAINTERLY) {
    return {
      drawBody: true,
      drawStroke: earState.isNear && viewState.profile < 0.38 && !isBackSide,
      drawInner: false,
      drawSilhouette: !isProfileFar,
    };
  }
  return {
    drawBody: true,
    drawStroke: earState.isNear ? viewState.profile < 0.86 || isBackSide : viewState.profile < 0.36 || isBackSide,
    drawInner: earState.isNear && viewState.profile < 0.68 && viewState.back < 0.58,
    drawSilhouette: !isProfileFar,
  };
}

export function computeOutlinePolicy(viewState: ViewState, mode: OutlineMode): OutlinePolicy {
  const earPolicies = {
    earRight: computeEarPolicy(viewState.earRight, viewState, mode),
    earLeft: computeEarPolicy(viewState.earLeft, viewState, mode),
  };

  if (mode === OUTLINE_MODES.FULL) {
    return {
      drawMasterSilhouette: true,
      drawFaceStroke: true,
      drawNoseBody: viewState.showNose,
      drawNoseStroke: viewState.showNose,
      drawNoseDetail: viewState.showNose,
      drawMouth: viewState.showMouth,
      ears: earPolicies,
    };
  }
  if (mode === OUTLINE_MODES.SILHOUETTE_ONLY) {
    return {
      drawMasterSilhouette: true,
      drawFaceStroke: false,
      drawNoseBody: false,
      drawNoseStroke: false,
      drawNoseDetail: false,
      drawMouth: false,
      ears: earPolicies,
    };
  }
  if (mode === OUTLINE_MODES.PAINTERLY) {
    return {
      drawMasterSilhouette: true,
      drawFaceStroke: false,
      drawNoseBody: viewState.showNose,
      drawNoseStroke: viewState.showNose && viewState.noseFusion < 0.15,
      drawNoseDetail: viewState.zone !== "BACK_PROXY" && viewState.profile > 0.5,
      drawMouth: viewState.zone !== "BACK_PROXY" && viewState.profile < 0.9,
      ears: earPolicies,
    };
  }
  return {
    drawMasterSilhouette: true,
    drawFaceStroke: false,
    drawNoseBody: viewState.showNose,
    drawNoseStroke: viewState.showNose && viewState.noseFusion < 0.55,
    drawNoseDetail: viewState.zone !== "BACK_PROXY",
    drawMouth: viewState.zone !== "BACK_PROXY",
    ears: earPolicies,
  };
}
