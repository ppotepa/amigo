use crate::cli::Command;

#[derive(Debug, Clone, Copy)]
pub(super) struct CommandSpec {
    pub command: Command,
    pub name: &'static str,
    pub aliases: &'static [&'static str],
}

pub(super) const COMMAND_SPECS: &[CommandSpec] = &[
    CommandSpec {
        command: Command::Scan,
        name: "scan",
        aliases: &[],
    },
    CommandSpec {
        command: Command::Refresh,
        name: "refresh",
        aliases: &[],
    },
    CommandSpec {
        command: Command::Watch,
        name: "watch",
        aliases: &[],
    },
    CommandSpec {
        command: Command::Status,
        name: "status",
        aliases: &[],
    },
    CommandSpec {
        command: Command::Changes,
        name: "changes",
        aliases: &[],
    },
    CommandSpec {
        command: Command::Files,
        name: "files",
        aliases: &[],
    },
    CommandSpec {
        command: Command::Changed,
        name: "changed",
        aliases: &[],
    },
    CommandSpec {
        command: Command::Symbols,
        name: "symbols",
        aliases: &[],
    },
    CommandSpec {
        command: Command::Where,
        name: "where",
        aliases: &[],
    },
    CommandSpec {
        command: Command::Signature,
        name: "signature",
        aliases: &[],
    },
    CommandSpec {
        command: Command::Trace,
        name: "trace",
        aliases: &[],
    },
    CommandSpec {
        command: Command::TraceField,
        name: "trace-field",
        aliases: &[],
    },
    CommandSpec {
        command: Command::ChangePlan,
        name: "change-plan",
        aliases: &[],
    },
    CommandSpec {
        command: Command::ExplainFile,
        name: "explain-file",
        aliases: &[],
    },
    CommandSpec {
        command: Command::Neighbors,
        name: "neighbors",
        aliases: &[],
    },
    CommandSpec {
        command: Command::ApiSurface,
        name: "api-surface",
        aliases: &[],
    },
    CommandSpec {
        command: Command::ComponentGraph,
        name: "component-graph",
        aliases: &[],
    },
    CommandSpec {
        command: Command::TauriGraph,
        name: "tauri-graph",
        aliases: &[],
    },
    CommandSpec {
        command: Command::CallsiteCandidates,
        name: "callsite-candidates",
        aliases: &[],
    },
    CommandSpec {
        command: Command::TodoIndex,
        name: "todo-index",
        aliases: &[],
    },
    CommandSpec {
        command: Command::RiskIndex,
        name: "risk-index",
        aliases: &[],
    },
    CommandSpec {
        command: Command::Smells,
        name: "smells",
        aliases: &["refactor-candidates"],
    },
    CommandSpec {
        command: Command::Compact,
        name: "compact",
        aliases: &[],
    },
    CommandSpec {
        command: Command::Explain,
        name: "explain",
        aliases: &["--help", "-h"],
    },
    CommandSpec {
        command: Command::Brief,
        name: "brief",
        aliases: &[],
    },
    CommandSpec {
        command: Command::Find,
        name: "find",
        aliases: &[],
    },
    CommandSpec {
        command: Command::Scope,
        name: "scope",
        aliases: &[],
    },
    CommandSpec {
        command: Command::Refs,
        name: "refs",
        aliases: &[],
    },
    CommandSpec {
        command: Command::Docs,
        name: "docs",
        aliases: &["readme-coverage"],
    },
    CommandSpec {
        command: Command::CommandMap,
        name: "command-map",
        aliases: &[],
    },
    CommandSpec {
        command: Command::Anchors,
        name: "anchors",
        aliases: &[],
    },
    CommandSpec {
        command: Command::AnchorCheck,
        name: "anchor-check",
        aliases: &[],
    },
    CommandSpec {
        command: Command::Taxonomy,
        name: "taxonomy",
        aliases: &[],
    },
    CommandSpec {
        command: Command::Verify,
        name: "verify",
        aliases: &[],
    },
    CommandSpec {
        command: Command::VerifyPlan,
        name: "verify-plan",
        aliases: &[],
    },
    CommandSpec {
        command: Command::Stale,
        name: "stale",
        aliases: &[],
    },
    CommandSpec {
        command: Command::Impact,
        name: "impact",
        aliases: &[],
    },
    CommandSpec {
        command: Command::Fallout,
        name: "fallout",
        aliases: &[],
    },
    CommandSpec {
        command: Command::MovePlan,
        name: "move-plan",
        aliases: &[],
    },
    CommandSpec {
        command: Command::Dup,
        name: "dup",
        aliases: &[],
    },
    CommandSpec {
        command: Command::TauriCommands,
        name: "tauri-commands",
        aliases: &[],
    },
    CommandSpec {
        command: Command::ServiceShape,
        name: "service-shape",
        aliases: &[],
    },
    CommandSpec {
        command: Command::RegistryCheck,
        name: "registry-check",
        aliases: &[],
    },
    CommandSpec {
        command: Command::MetadataAudit,
        name: "metadata-audit",
        aliases: &[],
    },
    CommandSpec {
        command: Command::DescriptorSkeleton,
        name: "descriptor-skeleton",
        aliases: &[],
    },
    CommandSpec {
        command: Command::OperationsSummary,
        name: "operations-summary",
        aliases: &[],
    },
    CommandSpec {
        command: Command::CommitPlan,
        name: "commit-plan",
        aliases: &[],
    },
    CommandSpec {
        command: Command::CommitSummary,
        name: "commit-summary",
        aliases: &[],
    },
    CommandSpec {
        command: Command::AppendPlan,
        name: "append-plan",
        aliases: &[],
    },
    CommandSpec {
        command: Command::CopyPlan,
        name: "copy-plan",
        aliases: &[],
    },
    CommandSpec {
        command: Command::Slice,
        name: "slice",
        aliases: &[],
    },
    CommandSpec {
        command: Command::DiffScope,
        name: "diff-scope",
        aliases: &[],
    },
    CommandSpec {
        command: Command::DeletePlan,
        name: "delete-plan",
        aliases: &[],
    },
    CommandSpec {
        command: Command::FileMovePlan,
        name: "file-move-plan",
        aliases: &[],
    },
    CommandSpec {
        command: Command::RenamePlan,
        name: "rename-plan",
        aliases: &[],
    },
    CommandSpec {
        command: Command::ImportFixPlan,
        name: "import-fix-plan",
        aliases: &[],
    },
    CommandSpec {
        command: Command::OpenSet,
        name: "open-set",
        aliases: &[],
    },
    CommandSpec {
        command: Command::Workset,
        name: "workset",
        aliases: &[],
    },
    CommandSpec {
        command: Command::BarrelCheck,
        name: "barrel-check",
        aliases: &[],
    },
    CommandSpec {
        command: Command::OrphanFiles,
        name: "orphan-files",
        aliases: &[],
    },
    CommandSpec {
        command: Command::ShimCheck,
        name: "shim-check",
        aliases: &[],
    },
    CommandSpec {
        command: Command::LargeFiles,
        name: "large-files",
        aliases: &[],
    },
    CommandSpec {
        command: Command::AssetFileCheck,
        name: "asset-file-check",
        aliases: &[],
    },
    CommandSpec {
        command: Command::CaseCheck,
        name: "case-check",
        aliases: &[],
    },
    CommandSpec {
        command: Command::TextCheck,
        name: "text-check",
        aliases: &[],
    },
    CommandSpec {
        command: Command::PatchPreview,
        name: "patch-preview",
        aliases: &[],
    },
    CommandSpec {
        command: Command::PatchCheck,
        name: "patch-check",
        aliases: &[],
    },
    CommandSpec {
        command: Command::PatchApply,
        name: "patch-apply",
        aliases: &[],
    },
    CommandSpec {
        command: Command::OpsPreview,
        name: "ops-preview",
        aliases: &[],
    },
    CommandSpec {
        command: Command::OpsCheck,
        name: "ops-check",
        aliases: &[],
    },
    CommandSpec {
        command: Command::OpsApply,
        name: "ops-apply",
        aliases: &[],
    },
    CommandSpec {
        command: Command::OpsRawPreview,
        name: "ops-raw-preview",
        aliases: &[],
    },
    CommandSpec {
        command: Command::OpsRawCheck,
        name: "ops-raw-check",
        aliases: &[],
    },
    CommandSpec {
        command: Command::OpsRawApply,
        name: "ops-raw-apply",
        aliases: &[],
    },
    CommandSpec {
        command: Command::OpsSkeleton,
        name: "ops-skeleton",
        aliases: &[],
    },
    CommandSpec {
        command: Command::OpsSchema,
        name: "ops-schema",
        aliases: &[],
    },
    CommandSpec {
        command: Command::OpsSplit,
        name: "ops-split",
        aliases: &[],
    },
    CommandSpec {
        command: Command::OpsVerify,
        name: "ops-verify",
        aliases: &[],
    },
    CommandSpec {
        command: Command::OpsSummary,
        name: "ops-summary",
        aliases: &[],
    },
    CommandSpec {
        command: Command::RangeForSymbol,
        name: "range-for-symbol",
        aliases: &[],
    },
    CommandSpec {
        command: Command::RangeForLines,
        name: "range-for-lines",
        aliases: &[],
    },
    CommandSpec {
        command: Command::AnchorRange,
        name: "anchor-range",
        aliases: &[],
    },
    CommandSpec {
        command: Command::CommitFiles,
        name: "commit-files",
        aliases: &[],
    },
    CommandSpec {
        command: Command::ResolveSymbol,
        name: "resolve-symbol",
        aliases: &[],
    },
    CommandSpec {
        command: Command::PreviewEdit,
        name: "preview-edit",
        aliases: &[],
    },
    CommandSpec {
        command: Command::CompileEdit,
        name: "compile-edit",
        aliases: &[],
    },
    CommandSpec {
        command: Command::ReplaceSymbol,
        name: "replace-symbol",
        aliases: &[],
    },
    CommandSpec {
        command: Command::ReplaceMethodBody,
        name: "replace-method-body",
        aliases: &[],
    },
    CommandSpec {
        command: Command::ReplaceRange,
        name: "replace-range",
        aliases: &[],
    },
    CommandSpec {
        command: Command::InsertBeforeSymbol,
        name: "insert-before-symbol",
        aliases: &[],
    },
    CommandSpec {
        command: Command::InsertAfterSymbol,
        name: "insert-after-symbol",
        aliases: &[],
    },
    CommandSpec {
        command: Command::VerifyScope,
        name: "verify-scope",
        aliases: &[],
    },
];

pub(super) fn command_spec_by_name(value: &str) -> Option<&'static CommandSpec> {
    COMMAND_SPECS
        .iter()
        .find(|spec| spec.name == value || spec.aliases.contains(&value))
}
